-- =====================================================================
-- DOMPETIM v1.1 | 0005_views.sql
-- View laporan. security_invoker = RLS milik pemanggil tetap berlaku.
-- =====================================================================

create or replace view public.v_balance
with (security_invoker = true) as
select
  coalesce(sum(amount) filter (where type = 'income'),  0) as total_income,
  coalesce(sum(amount) filter (where type = 'expense'), 0) as total_expense,
  coalesce(sum(amount) filter (where type = 'income'),  0)
  - coalesce(sum(amount) filter (where type = 'expense'), 0) as balance
from public.transactions;

create or replace view public.v_monthly_summary
with (security_invoker = true) as
select
  date_trunc('month', trx_date)::date as month,
  coalesce(sum(amount) filter (where type = 'income'),  0) as income,
  coalesce(sum(amount) filter (where type = 'expense'), 0) as expense,
  coalesce(sum(amount) filter (where type = 'income'),  0)
  - coalesce(sum(amount) filter (where type = 'expense'), 0) as net
from public.transactions
group by 1
order by 1 desc;

create or replace view public.v_category_summary
with (security_invoker = true) as
select
  date_trunc('month', t.trx_date)::date as month,
  c.name as category,
  t.type,
  sum(t.amount) as total,
  count(*)      as trx_count
from public.transactions t
join public.categories c on c.id = t.category_id
group by 1, 2, 3
order by 1 desc, 4 desc;

create or replace view public.v_transactions
with (security_invoker = true) as
select
  t.id, t.type, t.amount, t.trx_date, t.counterparty, t.purpose,
  c.name as category, t.category_id,
  t.receipt_path, (t.receipt_path is not null) as has_receipt,
  t.created_by, t.created_at
from public.transactions t
join public.categories c on c.id = t.category_id
order by t.trx_date desc, t.created_at desc;

create or replace view public.v_dues_board
with (security_invoker = true) as
select
  d.id as due_id,
  d.period,
  m.id as member_id,
  m.full_name,
  m.email,
  d.amount,
  d.status,
  d.paid_at,
  (d.status = 'unpaid' and current_date > (d.period + (s.due_day - 1))) as is_overdue
from public.dues d
join public.members m on m.id = d.member_id
cross join public.settings s
order by d.period desc, m.full_name;

grant select on public.v_balance, public.v_monthly_summary, public.v_category_summary,
                public.v_transactions, public.v_dues_board to authenticated;
