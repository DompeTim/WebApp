-- =====================================================================
-- DOMPETIM v1.1 | 0002_triggers.sql
-- updated_at otomatis, penjaga integritas data, log aktivitas.
-- =====================================================================

-- ---------- updated_at otomatis ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_members_updated      on public.members;
drop trigger if exists trg_settings_updated     on public.settings;
drop trigger if exists trg_categories_updated   on public.categories;
drop trigger if exists trg_transactions_updated on public.transactions;
drop trigger if exists trg_dues_updated         on public.dues;

create trigger trg_members_updated      before update on public.members
  for each row execute function public.set_updated_at();
create trigger trg_settings_updated     before update on public.settings
  for each row execute function public.set_updated_at();
create trigger trg_categories_updated   before update on public.categories
  for each row execute function public.set_updated_at();
create trigger trg_transactions_updated before update on public.transactions
  for each row execute function public.set_updated_at();
create trigger trg_dues_updated         before update on public.dues
  for each row execute function public.set_updated_at();

-- ---------- PENJAGA: pengelola terakhir ----------
-- Menolak menghapus / menonaktifkan / menurunkan role / mengganti email
-- pengelola aktif TERAKHIR (agar tidak ada kondisi tanpa pengelola).
create or replace function public.guard_last_admin()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  if old.role = 'admin' and old.is_active then
    if tg_op = 'DELETE'
       or new.role <> 'admin'
       or not new.is_active
       or new.email <> old.email then
      if not exists (
        select 1 from public.members
        where id <> old.id and role = 'admin' and is_active
      ) then
        raise exception 'Pengelola aktif terakhir tidak boleh dihapus, dinonaktifkan, diturunkan role-nya, atau diganti emailnya. Tambahkan pengelola lain terlebih dahulu.'
          using errcode = 'P0001';
      end if;
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists trg_members_guard on public.members;
create trigger trg_members_guard before update or delete on public.members
  for each row execute function public.guard_last_admin();

-- ---------- PENJAGA: kategori sistem ----------
create or replace function public.guard_categories()
returns trigger
language plpgsql
as $$
begin
  if old.is_system then
    if tg_op = 'DELETE'
       or new.code      is distinct from old.code
       or new.type      is distinct from old.type
       or new.is_system <> old.is_system
       or not new.is_active then
      raise exception 'Kategori bawaan sistem tidak boleh dihapus, dinonaktifkan, atau diubah jenisnya.'
        using errcode = 'P0001';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists trg_categories_guard on public.categories;
create trigger trg_categories_guard before update or delete on public.categories
  for each row execute function public.guard_categories();

-- ---------- PENJAGA: transaksi ----------
-- 1) kategori harus sesuai tipe & aktif
-- 2) kategori 'iuran' hanya boleh dibuat lewat fungsi pay_due()
-- 3) transaksi yang terhubung ke iuran: nominal/tipe/kategori terkunci,
--    dan tidak boleh dihapus langsung (gunakan unpay_due())
create or replace function public.guard_transactions()
returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_cat public.categories%rowtype;
  v_via_rpc boolean := coalesce(current_setting('dompetim.via_rpc', true), '') = '1';
begin
  if tg_op = 'DELETE' then
    if exists (select 1 from public.dues where transaction_id = old.id) then
      raise exception 'Transaksi ini terhubung ke iuran. Batalkan pembayaran iuran (unpay_due) untuk menghapusnya.'
        using errcode = 'P0001';
    end if;
    return old;
  end if;

  select * into v_cat from public.categories where id = new.category_id;

  if v_cat.type is not null and v_cat.type <> new.type then
    raise exception 'Kategori "%" tidak sesuai dengan tipe transaksi', v_cat.name
      using errcode = 'P0001';
  end if;

  if tg_op = 'INSERT' or new.category_id <> old.category_id then
    if not v_cat.is_active then
      raise exception 'Kategori "%" sudah tidak aktif', v_cat.name using errcode = 'P0001';
    end if;
    if v_cat.code = 'iuran' and not v_via_rpc then
      raise exception 'Kategori Iuran hanya dibuat otomatis saat iuran ditandai lunas'
        using errcode = 'P0001';
    end if;
  end if;

  if tg_op = 'UPDATE'
     and (new.amount <> old.amount or new.type <> old.type or new.category_id <> old.category_id)
     and exists (select 1 from public.dues where transaction_id = old.id) then
    raise exception 'Nominal, tipe, dan kategori transaksi iuran tidak boleh diubah. Batalkan lalu catat ulang lewat modul iuran.'
      using errcode = 'P0001';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_transactions_guard on public.transactions;
create trigger trg_transactions_guard before insert or update or delete on public.transactions
  for each row execute function public.guard_transactions();

-- ---------- PENJAGA: iuran lunas tidak boleh diubah diam-diam ----------
create or replace function public.guard_dues()
returns trigger
language plpgsql
as $$
begin
  if old.status = 'paid' and new.status = 'paid'
     and (new.member_id      <> old.member_id
       or new.period         <> old.period
       or new.amount         <> old.amount
       or new.paid_at        <> old.paid_at
       or new.transaction_id <> old.transaction_id) then
    raise exception 'Iuran yang sudah lunas tidak boleh diubah. Batalkan pembayaran terlebih dahulu.'
      using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_dues_guard on public.dues;
create trigger trg_dues_guard before update on public.dues
  for each row execute function public.guard_dues();

-- ---------- LOG AKTIVITAS ----------
-- Mencatat INSERT/UPDATE/DELETE. UPDATE yang tidak mengubah isi data
-- (selain updated_at) diabaikan agar log tidak penuh noise.
create or replace function public.log_audit()
returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_old jsonb := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end;
  v_new jsonb := case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end;
begin
  if tg_op = 'UPDATE' and (v_new - 'updated_at') = (v_old - 'updated_at') then
    return null;
  end if;

  insert into public.audit_log (table_name, record_id, action, old_data, new_data, actor_email)
  values (
    tg_table_name,
    coalesce(v_new ->> 'id', v_old ->> 'id'),
    tg_op,
    v_old,
    v_new,
    nullif(public.current_email(), '')
  );
  return null; -- trigger AFTER: nilai kembalian diabaikan
end;
$$;

drop trigger if exists trg_members_audit      on public.members;
drop trigger if exists trg_settings_audit     on public.settings;
drop trigger if exists trg_categories_audit   on public.categories;
drop trigger if exists trg_transactions_audit on public.transactions;
drop trigger if exists trg_dues_audit         on public.dues;

create trigger trg_members_audit      after insert or update or delete on public.members
  for each row execute function public.log_audit();
create trigger trg_settings_audit     after insert or update or delete on public.settings
  for each row execute function public.log_audit();
create trigger trg_categories_audit   after insert or update or delete on public.categories
  for each row execute function public.log_audit();
create trigger trg_transactions_audit after insert or update or delete on public.transactions
  for each row execute function public.log_audit();
create trigger trg_dues_audit         after insert or update or delete on public.dues
  for each row execute function public.log_audit();
