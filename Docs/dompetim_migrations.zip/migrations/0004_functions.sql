-- =====================================================================
-- DOMPETIM v1.1 | 0004_functions.sql
-- Fungsi kerja (RPC) untuk modul iuran. SECURITY DEFINER karena tabel
-- dues tidak bisa ditulis langsung; setiap fungsi memeriksa is_admin().
-- =====================================================================

-- Buat tagihan iuran semua anggota aktif untuk satu bulan.
-- Contoh: select public.generate_dues('2026-12-01');  -> jumlah tagihan baru
create or replace function public.generate_dues(p_period date)
returns int
language plpgsql security definer
set search_path = public
as $$
declare
  v_period date := date_trunc('month', p_period)::date;
  v_amount numeric(14,2);
  v_count  int;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh membuat tagihan iuran' using errcode = '42501';
  end if;

  select monthly_due_amount into v_amount from public.settings where id = 1;
  if v_amount is null or v_amount <= 0 then
    raise exception 'Nominal iuran bulanan belum diatur (harus lebih dari 0)' using errcode = 'P0001';
  end if;

  insert into public.dues (member_id, period, amount)
  select m.id, v_period, v_amount
  from public.members m
  where m.is_active
  on conflict (member_id, period) do nothing;

  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- Tandai iuran lunas + otomatis catat pemasukan (kategori Iuran).
-- Contoh: select public.pay_due('<due_id>', current_date, null);  -> id transaksi
create or replace function public.pay_due(
  p_due_id       uuid,
  p_paid_at      date default current_date,
  p_receipt_path text default null
)
returns uuid
language plpgsql security definer
set search_path = public
as $$
declare
  v_due  public.dues%rowtype;
  v_name text;
  v_cat  uuid;
  v_trx  uuid;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh mencatat pembayaran iuran' using errcode = '42501';
  end if;

  select * into v_due from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_due.status = 'paid' then
    raise exception 'Iuran ini sudah berstatus lunas' using errcode = 'P0001';
  end if;

  select full_name into v_name from public.members where id = v_due.member_id;
  select id into v_cat from public.categories where code = 'iuran';

  -- izinkan pembuatan transaksi berkategori Iuran hanya di dalam transaksi ini
  perform set_config('dompetim.via_rpc', '1', true);

  insert into public.transactions (type, amount, trx_date, counterparty, purpose, category_id, receipt_path)
  values ('income', v_due.amount, p_paid_at, v_name,
          'Iuran ' || to_char(v_due.period, 'YYYY-MM'), v_cat, p_receipt_path)
  returning id into v_trx;

  perform set_config('dompetim.via_rpc', '', true);

  update public.dues
     set status = 'paid', paid_at = p_paid_at, transaction_id = v_trx
   where id = p_due_id;

  return v_trx;
end;
$$;

-- Batalkan status lunas (transaksi pemasukan terkait ikut dihapus).
create or replace function public.unpay_due(p_due_id uuid)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_due public.dues%rowtype;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh membatalkan pembayaran' using errcode = '42501';
  end if;

  select * into v_due from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_due.status <> 'paid' then
    raise exception 'Iuran ini belum berstatus lunas' using errcode = 'P0001';
  end if;

  update public.dues
     set status = 'unpaid', paid_at = null, transaction_id = null
   where id = p_due_id;

  delete from public.transactions where id = v_due.transaction_id;
end;
$$;

-- Hapus tagihan yang belum lunas (misal salah buat). Yang lunas tidak boleh.
create or replace function public.delete_due(p_due_id uuid)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_status public.due_status;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh menghapus tagihan' using errcode = '42501';
  end if;

  select status into v_status from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_status = 'paid' then
    raise exception 'Tagihan yang sudah lunas tidak boleh dihapus. Batalkan pembayaran terlebih dahulu.'
      using errcode = 'P0001';
  end if;

  delete from public.dues where id = p_due_id;
end;
$$;

-- Hanya user login yang boleh memanggil fungsi kerja ini.
revoke all on function public.generate_dues(date)           from public, anon;
revoke all on function public.pay_due(uuid, date, text)     from public, anon;
revoke all on function public.unpay_due(uuid)               from public, anon;
revoke all on function public.delete_due(uuid)              from public, anon;
grant execute on function public.generate_dues(date)        to authenticated;
grant execute on function public.pay_due(uuid, date, text)  to authenticated;
grant execute on function public.unpay_due(uuid)            to authenticated;
grant execute on function public.delete_due(uuid)           to authenticated;
