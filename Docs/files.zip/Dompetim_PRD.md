# PRD: Dompetim

**Versi:** 1.1 (skema database sudah direview dan diuji)
**Tagline:** Kas tim yang transparan
**Jenis produk:** Aplikasi web pengelolaan uang kas untuk tim kantor

---

## 1. Ringkasan

Dompetim adalah website sederhana untuk mencatat uang kas tim kantor. Pengelola (1 orang) mencatat pemasukan (dari siapa) dan pengeluaran (untuk apa), sedangkan seluruh anggota (kurang dari 30 orang) bisa membuka dan melihat data kapan saja tanpa bisa mengubahnya. Tujuannya adalah transparansi dan menggantikan pencatatan manual di chat atau spreadsheet.

## 2. Tujuan dan Metrik Keberhasilan

**Tujuan**
1. Semua anggota bisa melihat saldo, riwayat transaksi, dan status iuran kapan saja.
2. Hanya pengelola yang dapat menambah, mengubah, atau menghapus data.
3. Setiap perubahan data tercatat dan dapat ditelusuri.
4. Biaya operasional nol (memakai tier gratis).

**Metrik**
- 100% transaksi tercatat di aplikasi (tidak ada lagi catatan di luar sistem).
- Anggota dapat melihat saldo terbaru dalam kurang dari 3 klik setelah login.
- Rekap bulanan dapat diekspor dalam kurang dari 1 menit.
- 0 kejadian anggota non-pengelola berhasil mengubah data.

## 3. Di Luar Cakupan (Non-Goals) Versi 1

- Pembayaran online / integrasi payment gateway (pembayaran iuran dicatat manual oleh pengelola).
- Pengingat iuran otomatis (email/WhatsApp), kandidat versi berikutnya.
- Banyak kelompok/organisasi dalam satu aplikasi (multi-tenant).
- Nominal iuran berbeda per anggota (v1: sama untuk semua).
- Aplikasi mobile native (v1: website responsif).
- Anggaran/budgeting dan persetujuan pengeluaran.

## 4. Pengguna dan Peran

| Peran | Jumlah | Hak akses |
|---|---|---|
| **Pengelola (admin)** | 1 (bisa ditambah) | Kelola penuh: transaksi, iuran, anggota, pengaturan, upload bukti. Juga bisa melihat semua. |
| **Anggota (member)** | < 30 | Hanya lihat (view only): saldo, transaksi, iuran, laporan, log aktivitas. |
| **Bukan anggota** | - | Tidak boleh melihat apa pun, walau punya akun Google. |

## 5. User Stories

**Anggota**
- Sebagai anggota, saya ingin login dengan akun Google agar tidak perlu membuat password baru.
- Sebagai anggota, saya ingin melihat saldo kas saat ini agar tahu kondisi keuangan tim.
- Sebagai anggota, saya ingin melihat daftar pemasukan (dari siapa) dan pengeluaran (untuk apa) agar yakin uang dikelola dengan benar.
- Sebagai anggota, saya ingin melihat bukti/nota pengeluaran agar bisa memverifikasi.
- Sebagai anggota, saya ingin melihat status iuran saya dan anggota lain (lunas/belum).
- Sebagai anggota, saya ingin melihat grafik dan rekap bulanan.
- Sebagai anggota, saya ingin melihat riwayat perubahan data agar yakin tidak ada manipulasi.

**Pengelola**
- Sebagai pengelola, saya ingin mencatat pemasukan dengan keterangan dari siapa.
- Sebagai pengelola, saya ingin mencatat pengeluaran dengan keterangan untuk apa, kategori, dan foto nota.
- Sebagai pengelola, saya ingin membuat tagihan iuran bulanan untuk semua anggota sekaligus.
- Sebagai pengelola, saya ingin menandai iuran lunas dan otomatis tercatat sebagai pemasukan.
- Sebagai pengelola, saya ingin menambah atau menonaktifkan anggota dan mengatur nominal iuran.
- Sebagai pengelola, saya ingin mengekspor rekap ke Excel atau PDF.

## 6. Kebutuhan Fungsional

### 6.1 Autentikasi dan Akses
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-01 | Login hanya dengan akun Google (Supabase Auth). | Wajib |
| F-02 | Hanya email yang terdaftar dan aktif di tabel `members` yang bisa melihat data (whitelist). | Wajib |
| F-03 | Pengguna yang login tetapi tidak terdaftar melihat halaman "Akun belum terdaftar, hubungi pengelola". | Wajib |
| F-04 | Aturan view-only vs admin ditegakkan di database (Row Level Security), bukan hanya di tampilan. | Wajib |
| F-05 | Tombol/menu kelola disembunyikan untuk anggota biasa. | Wajib |

### 6.2 Transaksi
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-10 | Admin menambah transaksi: tipe (masuk/keluar), jumlah, tanggal, **pihak** (dari siapa / kepada siapa), **keperluan** (untuk apa/keterangan), kategori. | Wajib |
| F-11 | Admin mengubah dan menghapus transaksi (konfirmasi sebelum hapus). | Wajib |
| F-12 | Daftar transaksi dengan filter tipe, bulan, kategori, dan pencarian teks. | Wajib |
| F-13 | Upload bukti/nota (JPG/PNG/WebP/PDF, maks 5 MB) pada transaksi; anggota dapat melihatnya. | Wajib |
| F-14 | Kategori berasal dari **daftar resmi** (tabel `categories`), bukan teks bebas. Bawaan: Iuran, Saldo awal (sistem), Donasi, Konsumsi, Hadiah, Acara, Operasional, Lainnya. Admin bisa menambah/menonaktifkan kategori. Kategori harus sesuai tipe (misal Donasi hanya untuk pemasukan). | Wajib |
| F-15 | Saldo awal dicatat sebagai pemasukan berkategori **Saldo awal** (kategori sistem). | Wajib |
| F-16 | Transaksi hasil iuran (kategori Iuran) tidak bisa dibuat manual, nominal/tipe/kategorinya terkunci, dan tidak bisa dihapus langsung; hanya lewat pembatalan iuran. | Wajib |

### 6.3 Iuran Bulanan
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-20 | Admin mengatur nominal iuran bulanan (sama untuk semua anggota) dan tanggal jatuh tempo. | Wajib |
| F-21 | Admin membuat tagihan iuran untuk satu bulan bagi semua anggota aktif (`generate_dues`). | Wajib |
| F-22 | Papan status iuran: matriks anggota x bulan dengan status lunas/belum. | Wajib |
| F-23 | Admin menandai lunas (`pay_due`): status berubah dan pemasukan otomatis dibuat dengan keterangan "Iuran YYYY-MM". | Wajib |
| F-24 | Admin dapat membatalkan status lunas (`unpay_due`), transaksi terkait ikut terhapus. | Wajib |
| F-25 | Admin dapat menghapus tagihan yang belum lunas (`delete_due`); tagihan lunas tidak bisa dihapus. | Wajib |
| F-26 | Tabel iuran tidak dapat ditulis langsung dari aplikasi; semua perubahan lewat fungsi F-21, F-23, F-24, F-25. | Wajib |
| F-27 | Pembuatan tagihan ditolak jika nominal iuran belum diatur (harus > 0). | Wajib |

### 6.4 Laporan
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-30 | Dashboard: saldo saat ini, total pemasukan, total pengeluaran, iuran belum lunas bulan berjalan. | Wajib |
| F-31 | Rekap per bulan (pemasukan, pengeluaran, selisih). | Wajib |
| F-32 | Grafik pemasukan vs pengeluaran per bulan. | Wajib |
| F-33 | Export ke Excel (.xlsx) dan PDF untuk rekap dan daftar transaksi. | Wajib |

### 6.5 Transparansi
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-40 | Setiap INSERT/UPDATE/DELETE pada transaksi, iuran, anggota, dan pengaturan dicatat otomatis ke `audit_log` (siapa, aksi, data lama/baru, waktu). | Wajib |
| F-41 | Halaman Log Aktivitas dapat dilihat semua anggota (read-only), tampil dalam bahasa mudah dibaca. | Wajib |
| F-42 | Log tidak dapat diubah atau dihapus dari aplikasi. | Wajib |

### 6.6 Manajemen Anggota
| ID | Kebutuhan | Prioritas |
|---|---|---|
| F-50 | Admin menambah anggota (nama + email Google) dan menentukan role. | Wajib |
| F-51 | Admin menonaktifkan anggota (tanpa menghapus riwayat). | Wajib |
| F-52 | Pengelola aktif terakhir tidak dapat dihapus, dinonaktifkan, diturunkan role-nya, atau diganti emailnya (dijaga di database). | Wajib |
| F-53 | Anggota yang sudah punya riwayat iuran tidak bisa dihapus; cukup dinonaktifkan. | Wajib |

## 7. Kebutuhan Non-Fungsional

- **Keamanan:** RLS aktif di semua tabel; `service_role` key tidak pernah dipakai di frontend; bucket bukti bersifat privat dan diakses lewat signed URL.
- **Performa:** halaman utama termuat < 2 detik untuk data sampai ribuan transaksi.
- **Responsif:** nyaman dipakai di HP (mayoritas anggota membuka lewat ponsel).
- **Bahasa:** antarmuka Bahasa Indonesia; format mata uang Rupiah (Rp 1.250.000); format tanggal Indonesia.
- **Biaya:** hanya tier gratis (Vercel + Supabase).
- **Ketersediaan:** proyek Supabase tier gratis dapat dijeda jika lama tidak aktif; pengelola perlu mengaktifkannya kembali bila terjadi.

## 8. Arsitektur dan Teknologi

| Lapisan | Pilihan |
|---|---|
| Frontend | Next.js (App Router, TypeScript), Tailwind CSS, Recharts |
| Backend/DB | Supabase: Postgres, Auth (Google), Storage |
| Hosting | Vercel (tier gratis) |
| Export | SheetJS (Excel), jsPDF atau print-to-PDF |
| Skema | `dompetim_schema.sql` (gabungan) atau folder `migrations/` (0001 sampai 0006) + `seed_admin.sql`. Mencakup tabel, penjaga integritas, RLS, log aktivitas, fungsi RPC, view laporan, storage. |

**Alur login:** Google OAuth lewat Supabase, lalu aplikasi memeriksa email di `members` dan `is_active`. Jika tidak ditemukan, tampilkan halaman akun belum terdaftar.

## 9. Model Data (ringkasan)

- `members`: email (unik, huruf kecil), full_name, role (`admin`/`member`), is_active
- `settings`: 1 baris; org_name, monthly_due_amount, due_day
- `categories`: code (untuk kategori sistem), name (unik tanpa peduli huruf besar/kecil), type (income/expense/null = keduanya), is_system, is_active
- `transactions`: type, amount, trx_date, counterparty, purpose, category_id (relasi ke `categories`), receipt_path, created_by
- `dues`: member_id, period (tanggal 1), amount, status, paid_at, transaction_id; unik per (member, period); lunas wajib punya paid_at dan transaction_id
- `audit_log`: table_name, record_id, action, old_data, new_data, actor_email, created_at
- View: `v_balance`, `v_monthly_summary`, `v_category_summary`, `v_transactions`, `v_dues_board` (termasuk penanda `is_overdue`)
- RPC: `generate_dues(period)`, `pay_due(due_id, paid_at, receipt_path)`, `unpay_due(due_id)`, `delete_due(due_id)`

**Relasi utama**
- `dues.member_id` -> `members.id` (restrict: anggota ber-riwayat tidak bisa dihapus)
- `dues.transaction_id` -> `transactions.id` (restrict dan unik: satu transaksi hanya untuk satu iuran)
- `transactions.category_id` -> `categories.id` (restrict: kategori terpakai tidak bisa dihapus)

## 10. Daftar Halaman

| Halaman | Isi | Akses |
|---|---|---|
| Login | Tombol "Masuk dengan Google" | Publik |
| Akun belum terdaftar | Pesan dan tombol keluar | Login, non-anggota |
| Dashboard | Saldo, ringkasan bulan ini, grafik, iuran belum lunas | Semua anggota |
| Transaksi | Daftar + filter + detail + bukti; tombol tambah/ubah/hapus | Lihat: semua; kelola: admin |
| Iuran | Matriks anggota x bulan; tombol buat tagihan dan tandai lunas | Lihat: semua; kelola: admin |
| Laporan | Rekap bulanan, grafik, export Excel/PDF | Semua anggota |
| Log Aktivitas | Riwayat perubahan | Semua anggota |
| Anggota | Daftar, tambah, nonaktifkan | Lihat: semua; kelola: admin |
| Pengaturan | Nominal iuran, tanggal jatuh tempo, nama organisasi | Admin |

## 11. Aturan Bisnis

1. Saldo = total pemasukan - total pengeluaran.
2. Iuran lunas selalu menghasilkan tepat satu transaksi pemasukan yang terhubung.
3. Satu anggota hanya punya satu tagihan per bulan.
4. Nominal tagihan "dibekukan" saat dibuat; perubahan nominal di pengaturan tidak mengubah tagihan lama.
5. Anggota nonaktif tidak mendapat tagihan baru, tetapi riwayatnya tetap tersimpan.
6. Jumlah transaksi dan nominal iuran harus > 0.
7. Hapus data bersifat permanen, tetapi jejaknya tetap ada di log aktivitas.
8. Kategori transaksi harus aktif dan sesuai tipe; kategori sistem (Iuran, Saldo awal) tidak dapat dihapus atau dinonaktifkan.
9. Transaksi iuran hanya lahir dari `pay_due` dan hanya hilang lewat `unpay_due`.
10. Log aktivitas tidak mencatat perubahan kosong (update yang tidak mengubah isi data).

## 12. Kriteria Penerimaan (Acceptance Criteria)

- [ ] Akun Google yang tidak terdaftar tidak dapat melihat data apa pun (diuji lewat API langsung, bukan hanya UI).
- [ ] Anggota biasa yang mencoba INSERT/UPDATE/DELETE langsung ke API ditolak oleh database.
- [ ] Menandai iuran lunas membuat 1 transaksi pemasukan dan status berubah; membatalkannya mengembalikan keduanya.
- [ ] Setiap perubahan data muncul di Log Aktivitas dengan email pelaku.
- [ ] Bukti yang diupload dapat dilihat anggota dan tidak dapat diakses tanpa login.
- [ ] Export Excel dan PDF sesuai data yang terlihat di layar.
- [ ] Tampilan nyaman di layar HP (lebar 360 px).
- [ ] Pengelola aktif terakhir tidak bisa dihapus/dinonaktifkan/diturunkan.
- [ ] Mengubah nominal atau menghapus langsung transaksi iuran ditolak; tagihan lunas tidak bisa dihapus.
- [ ] Tabel iuran tidak bisa ditulis langsung dari API, hanya lewat fungsi.
- [ ] Kategori tidak sesuai tipe atau sudah nonaktif ditolak.

## 13. Rencana Pengerjaan

| Fase | Isi |
|---|---|
| 1. Fondasi | Setup Next.js, Supabase, login Google, jalankan skema SQL, seed pengelola, halaman akun belum terdaftar |
| 2. Transaksi | CRUD transaksi, filter, kategori |
| 3. Iuran | Pengaturan nominal, buat tagihan, papan status, tandai lunas/batal |
| 4. Laporan | Dashboard, rekap bulanan, grafik, export Excel/PDF |
| 5. Bukti dan Audit | Upload nota, halaman log aktivitas |
| 6. Finishing | Responsif mobile, uji akses dengan akun anggota, deploy ke Vercel |

## 14. Risiko dan Mitigasi

| Risiko | Mitigasi |
|---|---|
| Hanya 1 pengelola (single point of failure) | Skema mendukung banyak admin; disarankan menambah 1 admin cadangan |
| Proyek Supabase tier gratis dijeda saat tidak aktif | Pantau berkala; aktifkan kembali dari dashboard bila perlu |
| Salah konfigurasi RLS membuka data | Uji akses dengan akun anggota dan non-anggota sebelum rilis |
| Salah input transaksi oleh pengelola | Fitur ubah/hapus + log aktivitas sebagai jejak |
| Bukti berisi data pribadi | Bucket privat, hanya anggota terdaftar yang bisa melihat |
| Pemilik proyek Supabase (akses SQL Editor) tetap bisa mengubah data apa pun termasuk log | Batasi akses dashboard Supabase ke 1-2 orang tepercaya; jangan klaim sistem kebal manipulasi bagi pemegang akses database |
| Semua anggota dapat melihat email anggota lain (di daftar anggota dan log) | Sepakati dengan tim; bila perlu sembunyikan email di UI |

## 15. Pertanyaan Terbuka

- Siapa admin cadangan (jika ada)?
- Berapa nominal iuran bulanan awal dan tanggal jatuh tempo?
- Berapa saldo awal kas (dicatat sebagai pemasukan kategori Saldo awal)?
- Apakah riwayat kas lama perlu diimpor dari spreadsheet?
- Versi berikutnya: apakah pengingat iuran lewat email/WhatsApp akan dibutuhkan?

---

## Lampiran: Cara Memakai Dokumen Ini di Claude Project

1. Buat Project baru bernama **Dompetim**.
2. Unggah `Dompetim_PRD.md` dan `dompetim_schema.sql` sebagai Project Knowledge (folder `migrations/` opsional, dipakai untuk pengembangan berikutnya).
3. Di Supabase: jalankan `dompetim_schema.sql`, lalu edit dan jalankan `seed_admin.sql`; aktifkan provider Google di Auth.
4. Mulai dari Fase 1 di bagian 13, satu fase per percakapan.
5. Contoh perintah awal: *"Berdasarkan PRD dan skema SQL di project knowledge, buatkan setup Next.js untuk Fase 1: login Google dengan Supabase, pengecekan whitelist di tabel members, dan halaman akun belum terdaftar."*

## Catatan Perubahan v1.1 (terhadap v1.0)

- Kategori menjadi tabel resmi (`categories`) dengan kategori sistem.
- Iuran hanya bisa diubah lewat fungsi; transaksi iuran dikunci dari pengubahan dan penghapusan langsung.
- Relasi anggota dan transaksi diubah ke `restrict` agar riwayat tidak hilang.
- Perlindungan pengelola aktif terakhir ditegakkan di database.
- Log aktivitas mengabaikan perubahan kosong.
- Skema dipecah menjadi migrasi bernomor dan aman dijalankan ulang.
- Ditambah fungsi `delete_due`, view `v_category_summary` dan `v_transactions`, penanda `is_overdue`, dan seed saldo awal.
