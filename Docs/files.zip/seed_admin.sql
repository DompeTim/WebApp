-- =====================================================================
-- DOMPETIM v1.1 | seed_admin.sql  (JALANKAN MANUAL, SEKALI SAJA)
-- Edit nilai di bawah, lalu jalankan di Supabase SQL Editor
-- (SQL Editor melewati RLS, jadi bisa dipakai sebelum ada admin).
-- =====================================================================

insert into public.members (email, full_name, role)
values (lower('GANTI_dengan_email_google_pengelola@gmail.com'), 'GANTI Nama Pengelola', 'admin')
on conflict (email) do nothing;

-- Nominal iuran bulanan (contoh Rp 50.000), wajib > 0 sebelum membuat tagihan:
update public.settings set monthly_due_amount = 50000, due_day = 10 where id = 1;

-- Saldo awal (opsional). Hapus tanda komentar bila kas sudah punya saldo:
-- insert into public.transactions (type, amount, trx_date, counterparty, purpose, category_id)
-- select 'income', 1000000, current_date, 'Saldo awal', 'Saldo awal kas sebelum memakai Dompetim', id
-- from public.categories where code = 'saldo_awal';
