-- =====================================================================
-- DOMPETIM v1.1 - Skema Database LENGKAP (gabungan migrasi 0001-0006)
-- Jalankan seluruh file ini di Supabase > SQL Editor pada proyek baru.
-- Aman dijalankan ulang (idempotent) untuk skema yang sama.
-- Setelah itu jalankan seed_admin.sql (setelah diedit) untuk pengelola pertama.
-- Untuk pengembangan lanjutan, gunakan folder migrations/ (satu file per perubahan).
-- =====================================================================


-- ########## 0001_base.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0001_base.sql
-- Ekstensi, enum, tabel, indeks, data referensi, fungsi hak akses.
-- Aman dijalankan ulang (idempotent) pada database kosong atau yang sudah
-- berisi skema ini. Catatan: menjalankan ulang TIDAK mengubah struktur
-- tabel yang sudah ada; perubahan struktur ditulis sebagai migrasi baru.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- ENUM ----------
do $$ begin create type public.member_role as enum ('admin', 'member');
exception when duplicate_object then null; end $$;

do $$ begin create type public.trx_type as enum ('income', 'expense');
exception when duplicate_object then null; end $$;

do $$ begin create type public.due_status as enum ('unpaid', 'paid');
exception when duplicate_object then null; end $$;

-- ---------- IDENTITAS LOGIN ----------
-- Email user yang sedang login (dari JWT Supabase), huruf kecil.
create or replace function public.current_email()
returns text
language sql stable
as $$
  select lower(coalesce(auth.jwt() ->> 'email', ''));
$$;

-- ---------- TABEL ----------
-- Anggota = whitelist login + penentu role
create table if not exists public.members (
  id          uuid primary key default gen_random_uuid(),
  email       text not null unique,
  full_name   text not null check (length(trim(full_name)) > 0),
  role        public.member_role not null default 'member',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint members_email_lowercase check (email = lower(email))
);

-- Pengaturan aplikasi (selalu 1 baris)
create table if not exists public.settings (
  id                  int primary key default 1,
  org_name            text not null default 'Dompetim',
  monthly_due_amount  numeric(14,2) not null default 0 check (monthly_due_amount >= 0),
  due_day             int not null default 10 check (due_day between 1 and 28),
  updated_at          timestamptz not null default now(),
  constraint settings_single_row check (id = 1)
);

-- Kategori transaksi (daftar resmi, tidak teks bebas)
--   code     : kode tetap untuk kategori sistem (dipakai oleh fungsi)
--   type     : null = bisa untuk pemasukan maupun pengeluaran
--   is_system: kategori bawaan yang tidak boleh dihapus/diubah jenisnya
create table if not exists public.categories (
  id          uuid primary key default gen_random_uuid(),
  code        text unique,
  name        text not null check (length(trim(name)) > 0),
  type        public.trx_type,
  is_system   boolean not null default false,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create unique index if not exists categories_name_uniq on public.categories (lower(name));

-- Transaksi kas
create table if not exists public.transactions (
  id            uuid primary key default gen_random_uuid(),
  type          public.trx_type not null,
  amount        numeric(14,2) not null check (amount > 0),
  trx_date      date not null default current_date,
  counterparty  text not null check (length(trim(counterparty)) > 0), -- masuk: DARI SIAPA | keluar: kepada siapa/vendor
  purpose       text not null check (length(trim(purpose)) > 0),      -- masuk: keterangan | keluar: UNTUK APA
  category_id   uuid not null references public.categories(id) on delete restrict,
  receipt_path  text,                                                 -- path file di bucket 'receipts'
  created_by    text not null default public.current_email(),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists transactions_date_idx     on public.transactions (trx_date desc);
create index if not exists transactions_type_idx     on public.transactions (type);
create index if not exists transactions_category_idx on public.transactions (category_id);

-- Iuran bulanan per anggota
create table if not exists public.dues (
  id              uuid primary key default gen_random_uuid(),
  member_id       uuid not null references public.members(id) on delete restrict,
  period          date not null check (period = date_trunc('month', period)::date), -- selalu tanggal 1
  amount          numeric(14,2) not null check (amount > 0),
  status          public.due_status not null default 'unpaid',
  paid_at         date,
  transaction_id  uuid unique references public.transactions(id) on delete restrict,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (member_id, period),
  -- lunas WAJIB punya tanggal bayar + transaksi; belum lunas WAJIB kosong keduanya
  constraint dues_paid_consistency check (
    (status = 'paid'   and paid_at is not null and transaction_id is not null) or
    (status = 'unpaid' and paid_at is null     and transaction_id is null)
  )
);
create index if not exists dues_period_idx on public.dues (period);

-- Log aktivitas
create table if not exists public.audit_log (
  id          bigint generated always as identity primary key,
  table_name  text not null,
  record_id   text,
  action      text not null check (action in ('INSERT','UPDATE','DELETE')),
  old_data    jsonb,
  new_data    jsonb,
  actor_email text,
  created_at  timestamptz not null default now()
);
create index if not exists audit_log_created_idx on public.audit_log (created_at desc);
create index if not exists audit_log_table_idx   on public.audit_log (table_name, record_id);

-- ---------- FUNGSI HAK AKSES ----------
-- Anggota aktif (whitelist)?
create or replace function public.is_member()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.members m
    where m.email = public.current_email() and m.is_active
  );
$$;

-- Pengelola aktif?
create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.members m
    where m.email = public.current_email() and m.is_active and m.role = 'admin'
  );
$$;

-- ---------- DATA REFERENSI ----------
insert into public.settings (id) values (1) on conflict do nothing;

insert into public.categories (code, name, type, is_system) values
  ('iuran',      'Iuran',       'income',  true),
  ('saldo_awal', 'Saldo awal',  'income',  true),
  (null,         'Donasi',      'income',  false),
  (null,         'Konsumsi',    'expense', false),
  (null,         'Hadiah',      'expense', false),
  (null,         'Acara',       'expense', false),
  (null,         'Operasional', 'expense', false),
  (null,         'Lainnya',     null,      false)
on conflict do nothing;

-- ########## 0002_triggers.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0002_triggers.sql
-- updated_at otomatis, penjaga integritas data, log aktivitas.
-- =====================================================================

-- ---------- updated_at otomatis ----------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_members_updated      on public.members;
drop trigger if exists trg_settings_updated     on public.settings;
drop trigger if exists trg_categories_updated   on public.categories;
drop trigger if exists trg_transactions_updated on public.transactions;
drop trigger if exists trg_dues_updated         on public.dues;

create trigger trg_members_updated      before update on public.members
  for each row execute function public.set_updated_at();
create trigger trg_settings_updated     before update on public.settings
  for each row execute function public.set_updated_at();
create trigger trg_categories_updated   before update on public.categories
  for each row execute function public.set_updated_at();
create trigger trg_transactions_updated before update on public.transactions
  for each row execute function public.set_updated_at();
create trigger trg_dues_updated         before update on public.dues
  for each row execute function public.set_updated_at();

-- ---------- PENJAGA: pengelola terakhir ----------
-- Menolak menghapus / menonaktifkan / menurunkan role / mengganti email
-- pengelola aktif TERAKHIR (agar tidak ada kondisi tanpa pengelola).
create or replace function public.guard_last_admin()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  if old.role = 'admin' and old.is_active then
    if tg_op = 'DELETE'
       or new.role <> 'admin'
       or not new.is_active
       or new.email <> old.email then
      if not exists (
        select 1 from public.members
        where id <> old.id and role = 'admin' and is_active
      ) then
        raise exception 'Pengelola aktif terakhir tidak boleh dihapus, dinonaktifkan, diturunkan role-nya, atau diganti emailnya. Tambahkan pengelola lain terlebih dahulu.'
          using errcode = 'P0001';
      end if;
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists trg_members_guard on public.members;
create trigger trg_members_guard before update or delete on public.members
  for each row execute function public.guard_last_admin();

-- ---------- PENJAGA: kategori sistem ----------
create or replace function public.guard_categories()
returns trigger
language plpgsql
as $$
begin
  if old.is_system then
    if tg_op = 'DELETE'
       or new.code      is distinct from old.code
       or new.type      is distinct from old.type
       or new.is_system <> old.is_system
       or not new.is_active then
      raise exception 'Kategori bawaan sistem tidak boleh dihapus, dinonaktifkan, atau diubah jenisnya.'
        using errcode = 'P0001';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists trg_categories_guard on public.categories;
create trigger trg_categories_guard before update or delete on public.categories
  for each row execute function public.guard_categories();

-- ---------- PENJAGA: transaksi ----------
-- 1) kategori harus sesuai tipe & aktif
-- 2) kategori 'iuran' hanya boleh dibuat lewat fungsi pay_due()
-- 3) transaksi yang terhubung ke iuran: nominal/tipe/kategori terkunci,
--    dan tidak boleh dihapus langsung (gunakan unpay_due())
create or replace function public.guard_transactions()
returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_cat public.categories%rowtype;
  v_via_rpc boolean := coalesce(current_setting('dompetim.via_rpc', true), '') = '1';
begin
  if tg_op = 'DELETE' then
    if exists (select 1 from public.dues where transaction_id = old.id) then
      raise exception 'Transaksi ini terhubung ke iuran. Batalkan pembayaran iuran (unpay_due) untuk menghapusnya.'
        using errcode = 'P0001';
    end if;
    return old;
  end if;

  select * into v_cat from public.categories where id = new.category_id;

  if v_cat.type is not null and v_cat.type <> new.type then
    raise exception 'Kategori "%" tidak sesuai dengan tipe transaksi', v_cat.name
      using errcode = 'P0001';
  end if;

  if tg_op = 'INSERT' or new.category_id <> old.category_id then
    if not v_cat.is_active then
      raise exception 'Kategori "%" sudah tidak aktif', v_cat.name using errcode = 'P0001';
    end if;
    if v_cat.code = 'iuran' and not v_via_rpc then
      raise exception 'Kategori Iuran hanya dibuat otomatis saat iuran ditandai lunas'
        using errcode = 'P0001';
    end if;
  end if;

  if tg_op = 'UPDATE'
     and (new.amount <> old.amount or new.type <> old.type or new.category_id <> old.category_id)
     and exists (select 1 from public.dues where transaction_id = old.id) then
    raise exception 'Nominal, tipe, dan kategori transaksi iuran tidak boleh diubah. Batalkan lalu catat ulang lewat modul iuran.'
      using errcode = 'P0001';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_transactions_guard on public.transactions;
create trigger trg_transactions_guard before insert or update or delete on public.transactions
  for each row execute function public.guard_transactions();

-- ---------- PENJAGA: iuran lunas tidak boleh diubah diam-diam ----------
create or replace function public.guard_dues()
returns trigger
language plpgsql
as $$
begin
  if old.status = 'paid' and new.status = 'paid'
     and (new.member_id      <> old.member_id
       or new.period         <> old.period
       or new.amount         <> old.amount
       or new.paid_at        <> old.paid_at
       or new.transaction_id <> old.transaction_id) then
    raise exception 'Iuran yang sudah lunas tidak boleh diubah. Batalkan pembayaran terlebih dahulu.'
      using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_dues_guard on public.dues;
create trigger trg_dues_guard before update on public.dues
  for each row execute function public.guard_dues();

-- ---------- LOG AKTIVITAS ----------
-- Mencatat INSERT/UPDATE/DELETE. UPDATE yang tidak mengubah isi data
-- (selain updated_at) diabaikan agar log tidak penuh noise.
create or replace function public.log_audit()
returns trigger
language plpgsql security definer
set search_path = public
as $$
declare
  v_old jsonb := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end;
  v_new jsonb := case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end;
begin
  if tg_op = 'UPDATE' and (v_new - 'updated_at') = (v_old - 'updated_at') then
    return null;
  end if;

  insert into public.audit_log (table_name, record_id, action, old_data, new_data, actor_email)
  values (
    tg_table_name,
    coalesce(v_new ->> 'id', v_old ->> 'id'),
    tg_op,
    v_old,
    v_new,
    nullif(public.current_email(), '')
  );
  return null; -- trigger AFTER: nilai kembalian diabaikan
end;
$$;

drop trigger if exists trg_members_audit      on public.members;
drop trigger if exists trg_settings_audit     on public.settings;
drop trigger if exists trg_categories_audit   on public.categories;
drop trigger if exists trg_transactions_audit on public.transactions;
drop trigger if exists trg_dues_audit         on public.dues;

create trigger trg_members_audit      after insert or update or delete on public.members
  for each row execute function public.log_audit();
create trigger trg_settings_audit     after insert or update or delete on public.settings
  for each row execute function public.log_audit();
create trigger trg_categories_audit   after insert or update or delete on public.categories
  for each row execute function public.log_audit();
create trigger trg_transactions_audit after insert or update or delete on public.transactions
  for each row execute function public.log_audit();
create trigger trg_dues_audit         after insert or update or delete on public.dues
  for each row execute function public.log_audit();

-- ########## 0003_rls.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0003_rls.sql
-- Row Level Security. Semua anggota aktif = SELECT. Admin = kelola.
-- Tabel dues & audit_log TIDAK bisa ditulis langsung dari client
-- (dues hanya lewat fungsi di 0004; audit_log hanya lewat trigger).
-- =====================================================================

alter table public.members      enable row level security;
alter table public.settings     enable row level security;
alter table public.categories   enable row level security;
alter table public.transactions enable row level security;
alter table public.dues         enable row level security;
alter table public.audit_log    enable row level security;

-- members
drop policy if exists members_select on public.members;
drop policy if exists members_insert on public.members;
drop policy if exists members_update on public.members;
drop policy if exists members_delete on public.members;
create policy members_select on public.members for select to authenticated using (public.is_member());
create policy members_insert on public.members for insert to authenticated with check (public.is_admin());
create policy members_update on public.members for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy members_delete on public.members for delete to authenticated using (public.is_admin());

-- settings (satu baris tetap: tanpa insert/delete)
drop policy if exists settings_select on public.settings;
drop policy if exists settings_update on public.settings;
create policy settings_select on public.settings for select to authenticated using (public.is_member());
create policy settings_update on public.settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- categories
drop policy if exists categories_select on public.categories;
drop policy if exists categories_insert on public.categories;
drop policy if exists categories_update on public.categories;
drop policy if exists categories_delete on public.categories;
create policy categories_select on public.categories for select to authenticated using (public.is_member());
create policy categories_insert on public.categories for insert to authenticated with check (public.is_admin() and not is_system);
create policy categories_update on public.categories for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy categories_delete on public.categories for delete to authenticated using (public.is_admin());

-- transactions
drop policy if exists transactions_select on public.transactions;
drop policy if exists transactions_insert on public.transactions;
drop policy if exists transactions_update on public.transactions;
drop policy if exists transactions_delete on public.transactions;
create policy transactions_select on public.transactions for select to authenticated using (public.is_member());
create policy transactions_insert on public.transactions for insert to authenticated with check (public.is_admin());
create policy transactions_update on public.transactions for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy transactions_delete on public.transactions for delete to authenticated using (public.is_admin());

-- dues: hanya SELECT; penulisan lewat fungsi generate_dues / pay_due / unpay_due / delete_due
drop policy if exists dues_select on public.dues;
create policy dues_select on public.dues for select to authenticated using (public.is_member());

-- audit_log: hanya SELECT
drop policy if exists audit_log_select on public.audit_log;
create policy audit_log_select on public.audit_log for select to authenticated using (public.is_member());

-- ---------- HAK TABEL (lapisan kedua di atas RLS) ----------
revoke all on public.members, public.settings, public.categories,
              public.transactions, public.dues, public.audit_log from anon;

revoke insert, update, delete, truncate on public.dues      from authenticated;
revoke insert, update, delete, truncate on public.audit_log from authenticated;

-- ########## 0004_functions.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0004_functions.sql
-- Fungsi kerja (RPC) untuk modul iuran. SECURITY DEFINER karena tabel
-- dues tidak bisa ditulis langsung; setiap fungsi memeriksa is_admin().
-- =====================================================================

-- Buat tagihan iuran semua anggota aktif untuk satu bulan.
-- Contoh: select public.generate_dues('2026-12-01');  -> jumlah tagihan baru
create or replace function public.generate_dues(p_period date)
returns int
language plpgsql security definer
set search_path = public
as $$
declare
  v_period date := date_trunc('month', p_period)::date;
  v_amount numeric(14,2);
  v_count  int;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh membuat tagihan iuran' using errcode = '42501';
  end if;

  select monthly_due_amount into v_amount from public.settings where id = 1;
  if v_amount is null or v_amount <= 0 then
    raise exception 'Nominal iuran bulanan belum diatur (harus lebih dari 0)' using errcode = 'P0001';
  end if;

  insert into public.dues (member_id, period, amount)
  select m.id, v_period, v_amount
  from public.members m
  where m.is_active
  on conflict (member_id, period) do nothing;

  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- Tandai iuran lunas + otomatis catat pemasukan (kategori Iuran).
-- Contoh: select public.pay_due('<due_id>', current_date, null);  -> id transaksi
create or replace function public.pay_due(
  p_due_id       uuid,
  p_paid_at      date default current_date,
  p_receipt_path text default null
)
returns uuid
language plpgsql security definer
set search_path = public
as $$
declare
  v_due  public.dues%rowtype;
  v_name text;
  v_cat  uuid;
  v_trx  uuid;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh mencatat pembayaran iuran' using errcode = '42501';
  end if;

  select * into v_due from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_due.status = 'paid' then
    raise exception 'Iuran ini sudah berstatus lunas' using errcode = 'P0001';
  end if;

  select full_name into v_name from public.members where id = v_due.member_id;
  select id into v_cat from public.categories where code = 'iuran';

  -- izinkan pembuatan transaksi berkategori Iuran hanya di dalam transaksi ini
  perform set_config('dompetim.via_rpc', '1', true);

  insert into public.transactions (type, amount, trx_date, counterparty, purpose, category_id, receipt_path)
  values ('income', v_due.amount, p_paid_at, v_name,
          'Iuran ' || to_char(v_due.period, 'YYYY-MM'), v_cat, p_receipt_path)
  returning id into v_trx;

  perform set_config('dompetim.via_rpc', '', true);

  update public.dues
     set status = 'paid', paid_at = p_paid_at, transaction_id = v_trx
   where id = p_due_id;

  return v_trx;
end;
$$;

-- Batalkan status lunas (transaksi pemasukan terkait ikut dihapus).
create or replace function public.unpay_due(p_due_id uuid)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_due public.dues%rowtype;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh membatalkan pembayaran' using errcode = '42501';
  end if;

  select * into v_due from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_due.status <> 'paid' then
    raise exception 'Iuran ini belum berstatus lunas' using errcode = 'P0001';
  end if;

  update public.dues
     set status = 'unpaid', paid_at = null, transaction_id = null
   where id = p_due_id;

  delete from public.transactions where id = v_due.transaction_id;
end;
$$;

-- Hapus tagihan yang belum lunas (misal salah buat). Yang lunas tidak boleh.
create or replace function public.delete_due(p_due_id uuid)
returns void
language plpgsql security definer
set search_path = public
as $$
declare
  v_status public.due_status;
begin
  if not public.is_admin() then
    raise exception 'Hanya pengelola yang boleh menghapus tagihan' using errcode = '42501';
  end if;

  select status into v_status from public.dues where id = p_due_id for update;
  if not found then
    raise exception 'Iuran tidak ditemukan' using errcode = 'P0001';
  end if;
  if v_status = 'paid' then
    raise exception 'Tagihan yang sudah lunas tidak boleh dihapus. Batalkan pembayaran terlebih dahulu.'
      using errcode = 'P0001';
  end if;

  delete from public.dues where id = p_due_id;
end;
$$;

-- Hanya user login yang boleh memanggil fungsi kerja ini.
revoke all on function public.generate_dues(date)           from public, anon;
revoke all on function public.pay_due(uuid, date, text)     from public, anon;
revoke all on function public.unpay_due(uuid)               from public, anon;
revoke all on function public.delete_due(uuid)              from public, anon;
grant execute on function public.generate_dues(date)        to authenticated;
grant execute on function public.pay_due(uuid, date, text)  to authenticated;
grant execute on function public.unpay_due(uuid)            to authenticated;
grant execute on function public.delete_due(uuid)           to authenticated;

-- ########## 0005_views.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0005_views.sql
-- View laporan. security_invoker = RLS milik pemanggil tetap berlaku.
-- =====================================================================

create or replace view public.v_balance
with (security_invoker = true) as
select
  coalesce(sum(amount) filter (where type = 'income'),  0) as total_income,
  coalesce(sum(amount) filter (where type = 'expense'), 0) as total_expense,
  coalesce(sum(amount) filter (where type = 'income'),  0)
  - coalesce(sum(amount) filter (where type = 'expense'), 0) as balance
from public.transactions;

create or replace view public.v_monthly_summary
with (security_invoker = true) as
select
  date_trunc('month', trx_date)::date as month,
  coalesce(sum(amount) filter (where type = 'income'),  0) as income,
  coalesce(sum(amount) filter (where type = 'expense'), 0) as expense,
  coalesce(sum(amount) filter (where type = 'income'),  0)
  - coalesce(sum(amount) filter (where type = 'expense'), 0) as net
from public.transactions
group by 1
order by 1 desc;

create or replace view public.v_category_summary
with (security_invoker = true) as
select
  date_trunc('month', t.trx_date)::date as month,
  c.name as category,
  t.type,
  sum(t.amount) as total,
  count(*)      as trx_count
from public.transactions t
join public.categories c on c.id = t.category_id
group by 1, 2, 3
order by 1 desc, 4 desc;

create or replace view public.v_transactions
with (security_invoker = true) as
select
  t.id, t.type, t.amount, t.trx_date, t.counterparty, t.purpose,
  c.name as category, t.category_id,
  t.receipt_path, (t.receipt_path is not null) as has_receipt,
  t.created_by, t.created_at
from public.transactions t
join public.categories c on c.id = t.category_id
order by t.trx_date desc, t.created_at desc;

create or replace view public.v_dues_board
with (security_invoker = true) as
select
  d.id as due_id,
  d.period,
  m.id as member_id,
  m.full_name,
  m.email,
  d.amount,
  d.status,
  d.paid_at,
  (d.status = 'unpaid' and current_date > (d.period + (s.due_day - 1))) as is_overdue
from public.dues d
join public.members m on m.id = d.member_id
cross join public.settings s
order by d.period desc, m.full_name;

grant select on public.v_balance, public.v_monthly_summary, public.v_category_summary,
                public.v_transactions, public.v_dues_board to authenticated;

-- ########## 0006_storage.sql ##########
-- =====================================================================
-- DOMPETIM v1.1 | 0006_storage.sql
-- Bucket privat untuk bukti/nota. Saran path:
--   receipts/<tahun>/<id-transaksi>/<nama-file>
-- =====================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'receipts', 'receipts', false, 5242880,   -- maks 5 MB
  array['image/jpeg','image/png','image/webp','application/pdf']
)
on conflict (id) do nothing;

drop policy if exists receipts_select on storage.objects;
drop policy if exists receipts_insert on storage.objects;
drop policy if exists receipts_update on storage.objects;
drop policy if exists receipts_delete on storage.objects;

create policy receipts_select on storage.objects for select to authenticated
  using (bucket_id = 'receipts' and public.is_member());
create policy receipts_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'receipts' and public.is_admin());
create policy receipts_update on storage.objects for update to authenticated
  using (bucket_id = 'receipts' and public.is_admin())
  with check (bucket_id = 'receipts' and public.is_admin());
create policy receipts_delete on storage.objects for delete to authenticated
  using (bucket_id = 'receipts' and public.is_admin());
